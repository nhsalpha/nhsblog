<div class="entry-meta">
  <time class="published" datetime="<?php echo get_the_time('c'); ?>"><?php echo the_time('F jS Y'); ?></time>
  <div class="post-categories">
    <?php the_category(' | '); ?>
  </div>
</div>
