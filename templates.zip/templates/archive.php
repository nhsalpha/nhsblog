<main id="content" role="main" class="main main-archive">
  <?php get_template_part( 'partials/content', 'archive' ); ?>
</main>
