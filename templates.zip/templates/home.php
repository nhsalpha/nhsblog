<main id="content" role="main" class="main main-home">
  <?php get_template_part( 'partials/content', 'archive' ); ?>
</main>
